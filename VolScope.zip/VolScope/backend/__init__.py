"""Legacy VolScope Python reference."""
